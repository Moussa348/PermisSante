package com.tp2.ministry.service;

import com.tp2.ministry.model.Inhabitant;
import com.tp2.ministry.repository.InhabitantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InhabitantService {
    @Autowired
    private InhabitantRepository inhabitantRepository;

    public String getPermitTypeIfInhabitantIsValidWithSocialInsurance(String socialInsurance){
        Optional<Inhabitant> ministry = inhabitantRepository.findBySocialInsurance(socialInsurance);
        if(ministry.isPresent() && ministry.get().isActive())
            return ministry.get().getTypePermit();
        return "";
    }

    public String getPermitTypeIfInhabitantIsValidWithCellNumber(String cellNumber){
        Optional<Inhabitant> ministry = inhabitantRepository.findByCellNumber(cellNumber);
        if(ministry.isPresent() && ministry.get().isActive())
            return ministry.get().getTypePermit();
        return "";
    }

    public List<Inhabitant> findAll(){
         return inhabitantRepository.findAll();
    }

}
