package com.tp2.ministry.model;

import lombok.Builder;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
@Data
public class Inhabitant implements Serializable {

    @Id
    @GeneratedValue
    private Long id;
    private String firstName,lastName,socialInsurance,typePermit,cellNumber;
    private boolean active;

    public Inhabitant(){}

    @Builder
    public Inhabitant(String firstName, String lastName, String socialInsurance,
                      String typePermit, boolean active, String cellNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialInsurance = socialInsurance;
        this.typePermit = typePermit;
        this.cellNumber =cellNumber;
        this.active = active;
    }
}
