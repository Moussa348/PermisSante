package com.tp2.ministry.repository;

import com.tp2.ministry.model.Inhabitant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InhabitantRepository extends JpaRepository<Inhabitant,Long> {
    Optional<Inhabitant> findBySocialInsurance(String socialInsurance);
    Optional<Inhabitant> findByCellNumber(String cellNumber);
}
