package com.tp2.ministry.controller;

import com.tp2.ministry.model.Inhabitant;
import com.tp2.ministry.service.InhabitantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ministry")
public class InhabitantController {

    @Autowired
    private InhabitantService inhabitantService;

    @GetMapping("searchForRegistration/{socialInsurance}")
    public String getPermitTypeIfInhabitantIsValidWithSocialInsurance(@PathVariable String socialInsurance){
        return inhabitantService.getPermitTypeIfInhabitantIsValidWithSocialInsurance(socialInsurance);
    }

    @GetMapping("searchForRenewal/{cellNumber}")
    public String getPermitTypeIfInhabitantIsValidWithCellNumber(@PathVariable String cellNumber){
        return inhabitantService.getPermitTypeIfInhabitantIsValidWithCellNumber(cellNumber);
    }

    @GetMapping("/findAll")
    public List<Inhabitant> findAll(){
        return inhabitantService.findAll();
    }
}
