package com.tp2.ministry.repository;

import com.tp2.ministry.model.Inhabitant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class InhabitantRepositoryTest {

    @Autowired
    InhabitantRepository inhabitantRepository;

    @BeforeEach
    void insert(){
        List<Inhabitant> citizensInInhabitant = Arrays.asList(
                Inhabitant.builder()
                        .firstName("ara")
                        .lastName("araMa")
                        .socialInsurance("1234567")
                        .typePermit("TEST")
                        .cellNumber("5143324567")
                        .active(true)
                        .build(),
                Inhabitant.builder()
                        .firstName("ara")
                        .lastName("araMa")
                        .socialInsurance("4578990")
                        .typePermit("TEST")
                        .cellNumber("5142356754")
                        .active(false)
                        .build()
        );
        inhabitantRepository.saveAll(citizensInInhabitant);
    }

    @Test
    void findBySocialInsurance(){
        //Arrange
        Inhabitant inhabitant1 = Inhabitant.builder()
                .socialInsurance("1234567").build();
        Inhabitant inhabitant2 = Inhabitant.builder()
                .socialInsurance("345678").build();
        //Act
        Optional<Inhabitant> inhabitantExistent = inhabitantRepository.findBySocialInsurance(inhabitant1.getSocialInsurance());
        Optional<Inhabitant> inhabitantNotExistent = inhabitantRepository.findBySocialInsurance(inhabitant2.getSocialInsurance());
        //Assert
        assertTrue(inhabitantExistent.isPresent());
        assertFalse(inhabitantNotExistent.isPresent());
    }

    @Test
    void findByCellNumber(){
        //Arrange
        Inhabitant inhabitant1 = Inhabitant.builder()
                .cellNumber("5143324567").build();
        Inhabitant inhabitant2 = Inhabitant.builder()
                .cellNumber("51411111111").build();
        //Act
        Optional<Inhabitant> inhabitantExistent = inhabitantRepository.findByCellNumber(inhabitant1.getCellNumber());
        Optional<Inhabitant> inhabitantNotExistent = inhabitantRepository.findByCellNumber(inhabitant2.getCellNumber());
        //Assert
        assertTrue(inhabitantExistent.isPresent());
        assertFalse(inhabitantNotExistent.isPresent());
    }

}