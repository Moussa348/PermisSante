package com.tp2.ministry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InhabitantApplicationTests {

    @Test
    void contextLoads() {
    }

}
